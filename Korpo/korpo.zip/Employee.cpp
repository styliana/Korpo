#include "Employee.h"

Employee::Employee(std::string name, std::string lastname, int salary)
    : KorpoWorkers(name, lastname, salary) {}
