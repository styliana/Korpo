#include "Intern.h"

Intern::Intern(std::string name, std::string lastname)
    : KorpoWorkers(name, lastname, 0) {} // Default salary set to 0 for interns
